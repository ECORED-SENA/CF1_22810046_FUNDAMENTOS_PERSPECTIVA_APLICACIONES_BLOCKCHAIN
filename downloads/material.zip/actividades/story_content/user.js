function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5j4NMmDm8At":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

